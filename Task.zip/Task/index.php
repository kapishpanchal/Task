<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>Task Bootstrap Template - Article</title>
  <meta content="" name="description">
  <meta content="" name="keywords">

  <!-- Favicons -->
  <link href="assets/img/favicon.png" rel="icon">
  <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Open+Sans:ital,wght@0,300;0,400;0,500;0,600;0,700;1,300;1,400;1,600;1,700&family=Montserrat:ital,wght@0,300;0,400;0,500;0,600;0,700;1,300;1,400;1,500;1,600;1,700&family=Raleway:ital,wght@0,300;0,400;0,500;0,600;0,700;1,300;1,400;1,500;1,600;1,700&display=swap" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="assets/vendor/aos/aos.css" rel="stylesheet">
  <link href="assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
  <link href="assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">
  <link href="assets/vendor/remixicon/remixicon.css" rel="stylesheet">

  <!-- Template Main CSS File -->
  <link href="assets/css/main.css" rel="stylesheet">

  <!-- =======================================================
  * Template Name: Task
  * Updated: Sep 18 2023 with Bootstrap v5.3.2
  * Template URL: https://bootstrapmade.com/Task-bootstrap-business-template/
  * Author: BootstrapMade.com
  * License: https://bootstrapmade.com/license/
  ======================================================== -->
</head>

<body class="page-blog">

  <!-- ======= Header ======= -->
  <header id="header" class="header d-flex align-items-center fixed-top">
    <div class="container-fluid container-xl d-flex align-items-center justify-content-between">

      <a href="index.php" class="logo d-flex align-items-center">
        <!-- Uncomment the line below if you also wish to use an image logo -->
        <!-- <img src="assets/img/logo.png" alt=""> -->
        <h1 class="d-flex align-items-center">Task</h1>
      </a>

      <i class="mobile-nav-toggle mobile-nav-show bi bi-list"></i>
      <i class="mobile-nav-toggle mobile-nav-hide d-none bi bi-x"></i>

      <nav id="navbar" class="navbar">
        <ul>
          <li><a href="index.php">Home</a></li>
          
          <li><a href="add-article.php">Add Article</a></li>
        </ul>
      </nav><!-- .navbar -->

    </div>
  </header><!-- End Header -->

  <main id="main">

    <!-- ======= Breadcrumbs ======= -->
    <div class="breadcrumbs d-flex align-items-center" style="background-image: url('assets/img/blog-header.jpg');">
      <div class="container position-relative d-flex flex-column align-items-center">

        <h2>Article</h2>
        <ol>
          <li><a href="index.php">Home</a></li>
          <li>Article</li>
        </ol>

      </div>
    </div><!-- End Breadcrumbs -->

    <!-- ======= Blog Section ======= -->
    <section id="blog" class="blog">
      <div class="container" data-aos="fade-up">

        <div class="row g-5">

          <div class="col-lg-8" data-aos="fade-up" data-aos-delay="200">

            <div class="row gy-5 posts-list">

            <?php

            include('dbconnection.php');

            // Check if a sorting parameter is set in the URL
if(isset($_GET['sort']) && $_GET['sort'] == 'date') {
  $sort = 'date'; // Set the sorting parameter to 'date'
} else {
  $sort = ''; // Default sorting parameter
}

// Modify the SQL query based on the sorting parameter
if($sort == 'date') {
  $query = "SELECT * FROM `article` ORDER BY `date` DESC";
} else {
  $query = "SELECT * FROM `article`";
}

            // $query="SELECT *FROM `article`";
            $result=mysqli_query($conn,$query);

            
// Check if the search query is set in the URL
if(isset($_GET['query'])) {
  $searchQuery = $_GET['query'];

  // Perform a database query to search for articles based on the search query
  $query = "SELECT * FROM `article` WHERE `title` LIKE '%$searchQuery%' OR `description` LIKE '%$searchQuery%' OR 'slug' LIKE '%$searchQuery%'";
  $result = mysqli_query($conn, $query);

}

            while($row=mysqli_fetch_assoc($result))
            {
            echo'
              <div class="col-lg-6">
                <article class="d-flex flex-column">


                  <h2 class="title">
                    <a href="">Title - '. $row['title'].'</a>
                  </h2>

                  <div class="meta-top">
                    <ul>
                      <li class="d-flex align-items-center">Category - <a href="blog-details.php"> '. $row['category'].'</a></li>
                      <li class="d-flex align-items-center">Date - <a href="blog-details.php"><time datetime=" '. $row['date'].'">'.$row['date'].'</time></a></li>
                      <li class="d-flex align-items-center">Slug - <a href="blog-details.php"> '. $row['slug'].'</a></li>
                    </ul>
                  </div>

                  <div class="content">
                    <p>Description -
                    '. $row['description'].'
                    </p>
                  </div>

                  <div class="read-more mt-auto align-self-end">
                    <a href="editarticle.php?id='.$row['id'].'">Edit <i class="bi bi-arrow-right"></i></a>
                    <a href="delete.php?id='.$row['id'].'">Delete <i class="bi bi-arrow-right"></i></a>
                  </div>

                </article>
              </div>';
            }
              

              ?>

<button id="sortButton">Sort by Date</button>

<div class="sidebar-item search-form">
    <h3 class="sidebar-title">Search</h3>
    <form action="index.php" method="GET" class="mt-3"> <!-- Update the form action -->
        <input type="text" name="query" placeholder="Search...">
        <button type="submit"><i class="bi bi-search"></i></button>
    </form>
</div>





          </div>

         

          </div>

        </div>

      </div>
    </section><!-- End Blog Section -->

  </main><!-- End #main -->

  <!-- ======= Footer ======= -->
  <footer id="footer" class="footer">

    <div class="footer-content">
      <div class="container">
        <div class="row gy-4">
          <div class="col-lg-5 col-md-12 footer-info">
            <a href="index.php" class="logo d-flex align-items-center">
              <span>Task</span>
            </a>
            <p>Cras fermentum odio eu feugiat lide par naso tierra. Justo eget nada terra videa magna derita valies darta donna mare fermentum iaculis eu non diam phasellus.</p>
            <div class="social-links d-flex  mt-3">
              <a href="#" class="twitter"><i class="bi bi-twitter"></i></a>
              <a href="#" class="facebook"><i class="bi bi-facebook"></i></a>
              <a href="#" class="instagram"><i class="bi bi-instagram"></i></a>
              <a href="#" class="linkedin"><i class="bi bi-linkedin"></i></a>
            </div>
          </div>

          <div class="col-lg-2 col-6 footer-links">
            <h4>Useful Links</h4>
            <ul>
              <li><i class="bi bi-dash"></i> <a href="index.php">Home</a></li>
              
            </ul>
          </div>

          <div class="col-lg-2 col-6 footer-links">
            <h4>Our Services</h4>
            <ul>
              <li><i class="bi bi-dash"></i> <a href="#">Web Design</a></li>
              <li><i class="bi bi-dash"></i> <a href="#">Web Development</a></li>
              <li><i class="bi bi-dash"></i> <a href="#">Product Management</a></li>
              <li><i class="bi bi-dash"></i> <a href="#">Marketing</a></li>
              <li><i class="bi bi-dash"></i> <a href="#">Graphic Design</a></li>
            </ul>
          </div>

          <div class="col-lg-3 col-md-12 footer-contact text-center text-md-start">
            <h4>Contact Us</h4>
            <p>
              A108 Adam Street <br>
              New York, NY 535022<br>
              United States <br><br>
              <strong>Phone:</strong> +1 5589 55488 55<br>
              <strong>Email:</strong> info@example.com<br>
            </p>

          </div>

        </div>
      </div>
    </div>

    <div class="footer-legal">
      <div class="container">
        <div class="copyright">
          &copy; Copyright <strong><span>Task</span></strong>. All Rights Reserved
        </div>
        <div class="credits">
          <!-- All the links in the footer should remain intact. -->
          <!-- You can delete the links only if you purchased the pro version. -->
          <!-- Licensing information: https://bootstrapmade.com/license/ -->
          <!-- Purchase the pro version with working PHP/AJAX contact form: https://bootstrapmade.com/Task-bootstrap-business-template/ -->
          Designed by <a href="https://bootstrapmade.com/">BootstrapMade</a>
        </div>
      </div>
    </div>
  </footer><!-- End Footer --><!-- End Footer -->

  <a href="#" class="scroll-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>

  <div id="preloader"></div>
  <script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
  <!-- Vendor JS Files -->
  <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="assets/vendor/aos/aos.js"></script>
  <script src="assets/vendor/glightbox/js/glightbox.min.js"></script>
  <script src="assets/vendor/swiper/swiper-bundle.min.js"></script>
  <script src="assets/vendor/isotope-layout/isotope.pkgd.min.js"></script>
  <script src="assets/vendor/php-email-form/validate.js"></script>

  <!-- <script>
document.getElementById('sortButton').addEventListener('click', function() {
    window.location.href = window.location.pathname + '?sort=date';
});
</script> -->

<script>
document.addEventListener('DOMContentLoaded', function() {
    
    var urlParams = new URLSearchParams(window.location.search);
    var sortParam = urlParams.get('sort');

    var isSorted = (sortParam === 'date');

    function toggleSort() {
        if (isSorted) {
            window.history.replaceState({}, document.title, window.location.pathname);
        } else {
            window.history.replaceState({}, document.title, window.location.pathname + '?sort=date');
        }
        window.location.reload();
    }

    document.getElementById('sortButton').addEventListener('click', function() {
        toggleSort();
    });

    if (isSorted) {
        document.getElementById('sortButton').textContent = 'Unsort';
    }
});
</script>


  <!-- Template Main JS File -->
  <script src="assets/js/main.js"></script>

</body>

</html>