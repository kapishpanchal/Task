<?php

include('dbconnection.php');

    $id = $_POST['id'];
    $title = $_POST['title'];
    $category = $_POST['category'];
    $slug = $_POST['slug'];
    $description = $_POST['description'];


    $query = "UPDATE `article` SET title = '$title', slug = '$slug' , category = '$category', description = '$description' WHERE id = $id";
    $result=mysqli_query($conn, $query);

    if($result)
    {
        
        header("Location:blog.php");
        
    }
    else {
        echo "Error updating article: " . mysqli_error($conn);
    }

?>
