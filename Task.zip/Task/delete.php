<?php

include('dbconnection.php');

if(isset($_GET['id'])) {
    $id = $_GET['id'];



    $query = "DELETE FROM `article` WHERE id = $id";
    $result=mysqli_query($conn, $query);

    if($result)
    {
        // echo "Article updated successfully!";
        header("Location:blog.php");
        
    }
    else {
        echo "Error updating article: " . mysqli_error($conn);
    }
}
?>
