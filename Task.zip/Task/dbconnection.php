<?php

$server="127.0.0.1:3325";
$user="root";
$password="";
$db="task";

$conn=mysqli_connect($server,$user,$password,$db);

?>