<?php

include('dbconnection.php');

$title=$_POST["title"];
$category=$_POST["category"];
$slug=$_POST["slug"];
$description=$_POST["description"];

$query="INSERT INTO `article` (`title`,`category`,`slug`,`description`) VALUES ('$title','$category','$slug','$description')";
$result=mysqli_query($conn,$query);


?>